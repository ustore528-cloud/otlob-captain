import { prisma } from "../../lib/prisma.js";
import { HttpError } from "../../lib/http-error.js";
import { emitCaptainLocation } from "../../realtime/hub.js";
function toDto(c) {
    return {
        id: c.id,
        userId: c.userId,
        displayName: c.displayName,
        phone: c.phone,
        vehicleInfo: c.vehicleInfo,
        isActive: c.isActive,
        currentLatitude: c.currentLatitude,
        currentLongitude: c.currentLongitude,
        lastLocationAt: c.lastLocationAt ? c.lastLocationAt.toISOString() : null,
        updatedAt: c.updatedAt.toISOString(),
    };
}
export async function listCaptains() {
    const rows = await prisma.captainProfile.findMany({ orderBy: { updatedAt: "desc" } });
    return rows.map(toDto);
}
export async function upsertProfileForUser(userId, body) {
    const row = await prisma.captainProfile.upsert({
        where: { userId },
        create: {
            userId,
            displayName: body.displayName,
            phone: body.phone,
            vehicleInfo: body.vehicleInfo ?? null,
        },
        update: {
            displayName: body.displayName,
            phone: body.phone,
            vehicleInfo: body.vehicleInfo ?? null,
        },
    });
    return toDto(row);
}
export async function setAvailability(userId, body) {
    const profile = await prisma.captainProfile.findUnique({ where: { userId } });
    if (!profile)
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    const row = await prisma.captainProfile.update({
        where: { userId },
        data: { isActive: body.isActive },
    });
    return toDto(row);
}
export async function setAvailabilityByCaptainId(captainId, body) {
    try {
        const row = await prisma.captainProfile.update({
            where: { id: captainId },
            data: { isActive: body.isActive },
        });
        return toDto(row);
    }
    catch {
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    }
}
export async function updateLocation(userId, body) {
    const profile = await prisma.captainProfile.findUnique({ where: { userId } });
    if (!profile)
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    const row = await prisma.captainProfile.update({
        where: { userId },
        data: {
            currentLatitude: body.latitude,
            currentLongitude: body.longitude,
            lastHeading: body.heading ?? null,
            lastSpeedMps: body.speedMps ?? null,
            lastLocationAt: new Date(),
        },
    });
    emitCaptainLocation({
        captainId: row.id,
        userId: row.userId,
        latitude: row.currentLatitude,
        longitude: row.currentLongitude,
        heading: row.lastHeading,
        speedMps: row.lastSpeedMps,
        at: row.lastLocationAt?.toISOString() ?? null,
    });
    return toDto(row);
}
export async function getCaptainByUserId(userId) {
    const row = await prisma.captainProfile.findUnique({ where: { userId } });
    if (!row)
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    return toDto(row);
}
export async function getCaptainById(id) {
    const row = await prisma.captainProfile.findUnique({ where: { id } });
    if (!row)
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    return toDto(row);
}
