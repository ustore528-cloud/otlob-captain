import { Router } from "express";
import { z } from "zod";
import { CaptainAvailabilityBodySchema, CaptainLocationBodySchema, UpsertCaptainProfileBodySchema, } from "@captain/shared";
import { requireAuth, requireRoles } from "../../middleware/auth.js";
import { validateBody } from "../../middleware/validate.js";
import * as service from "./captain.service.js";
export const captainRouter = Router();
const idParams = z.object({ id: z.string().cuid() });
captainRouter.use(requireAuth);
captainRouter.get("/", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), async (_req, res, next) => {
    try {
        const items = await service.listCaptains();
        return res.json({ items });
    }
    catch (e) {
        return next(e);
    }
});
captainRouter.get("/me", requireRoles("CAPTAIN"), async (req, res, next) => {
    try {
        const row = await service.getCaptainByUserId(req.auth.userId);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
captainRouter.put("/me", requireRoles("CAPTAIN"), validateBody(UpsertCaptainProfileBodySchema), async (req, res, next) => {
    try {
        const row = await service.upsertProfileForUser(req.auth.userId, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
captainRouter.patch("/me/availability", requireRoles("CAPTAIN"), validateBody(CaptainAvailabilityBodySchema), async (req, res, next) => {
    try {
        const row = await service.setAvailability(req.auth.userId, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
captainRouter.post("/me/location", requireRoles("CAPTAIN"), validateBody(CaptainLocationBodySchema), async (req, res, next) => {
    try {
        const row = await service.updateLocation(req.auth.userId, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
captainRouter.get("/:id", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.getCaptainById(id);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
captainRouter.patch("/:id/availability", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), validateBody(CaptainAvailabilityBodySchema), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.setAvailabilityByCaptainId(id, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
