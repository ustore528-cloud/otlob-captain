import { ok } from "../utils/api-response.js";
import { trackingService } from "../services/tracking.service.js";
export const trackingController = {
    updateMyLocation: async (req, res) => {
        const body = req.body;
        const data = await trackingService.updateLocation(req.user.id, body.latitude, body.longitude);
        return res.json(ok(data));
    },
    latestLocations: async (req, res) => {
        const raw = req.query.captainIds;
        const ids = raw ? raw.split(",").map((s) => s.trim()).filter(Boolean) : [];
        const data = await trackingService.latestLocations(ids);
        return res.json(ok(data));
    },
    activeMap: async (_req, res) => {
        const data = await trackingService.activeCaptainsMap();
        return res.json(ok(data));
    },
};
