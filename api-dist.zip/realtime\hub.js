let io = null;
export function setIo(server) {
    io = server;
}
export function getIo() {
    return io;
}
export const rooms = {
    dispatchers: "dispatchers",
    store: (id) => `store:${id}`,
    captain: (id) => `captain:${id}`,
};
export function emitOrderUpdated(payload) {
    io?.to(rooms.dispatchers).emit("order:updated", payload);
}
export function emitOrderCreated(payload) {
    io?.to(rooms.dispatchers).emit("order:created", payload);
}
export function emitCaptainLocation(payload) {
    io?.to(rooms.dispatchers).emit("captain:location", payload);
}
export function emitToCaptain(captainUserId, event, payload) {
    io?.to(rooms.captain(captainUserId)).emit(event, payload);
}
