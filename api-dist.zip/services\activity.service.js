import { prisma } from "../lib/prisma.js";
export const activityService = {
    async log(userId, action, entityType, entityId, metadata) {
        await prisma.activityLog.create({
            data: {
                userId,
                action,
                entityType,
                entityId,
                metadata: metadata,
            },
        });
    },
    async logTx(tx, userId, action, entityType, entityId, metadata) {
        await tx.activityLog.create({
            data: {
                userId,
                action,
                entityType,
                entityId,
                metadata: metadata,
            },
        });
    },
};
