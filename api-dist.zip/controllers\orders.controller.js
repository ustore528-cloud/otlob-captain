import { $Enums } from "@prisma/client";
import { ok } from "../utils/api-response.js";
import { pathParam } from "../utils/path-params.js";
import { ordersService } from "../services/orders.service.js";
import { distributionService } from "../services/distribution/index.js";
const actor = (req) => ({
    userId: req.user.id,
    role: req.user.role,
    storeId: req.user.storeId,
});
export const ordersController = {
    create: async (req, res) => {
        const data = await ordersService.create(req.body, actor(req));
        return res.status(201).json(ok(data));
    },
    list: async (req, res) => {
        const q = req.query;
        const data = await ordersService.list({
            storeId: q.storeId,
            status: q.status,
            area: q.area,
            orderNumber: q.orderNumber,
            customerPhone: q.customerPhone,
            page: Number(q.page) || 1,
            pageSize: Number(q.pageSize) || 20,
        }, actor(req));
        return res.json(ok(data));
    },
    getById: async (req, res) => {
        const data = await ordersService.getById(pathParam(req, "id"), actor(req));
        return res.json(ok(data));
    },
    updateStatus: async (req, res) => {
        const body = req.body;
        const data = await ordersService.updateStatus(pathParam(req, "id"), body.status, actor(req));
        return res.json(ok(data));
    },
    accept: async (req, res) => {
        const data = await ordersService.acceptByCaptain(pathParam(req, "id"), req.user.id);
        return res.json(ok(data));
    },
    reject: async (req, res) => {
        const data = await ordersService.rejectByCaptain(pathParam(req, "id"), req.user.id);
        return res.json(ok(data));
    },
    reassign: async (req, res) => {
        const body = req.body;
        const data = await distributionService.reassign(pathParam(req, "id"), body.captainId, req.user.id);
        return res.json(ok(data));
    },
    startAutoDistribution: async (req, res) => {
        const data = await distributionService.startAuto(pathParam(req, "id"), req.user.id);
        return res.json(ok(data));
    },
    resendDistribution: async (req, res) => {
        const data = await distributionService.resendToDistribution(pathParam(req, "id"), req.user.id);
        return res.json(ok(data));
    },
    cancelCaptainAssignment: async (req, res) => {
        const data = await distributionService.cancelCaptainAssignment(pathParam(req, "id"), req.user.id);
        return res.json(ok(data));
    },
    manualAssign: async (req, res) => {
        const body = req.body;
        const mode = body.assignmentType === $Enums.AssignmentType.DRAG_DROP
            ? $Enums.AssignmentType.DRAG_DROP
            : $Enums.AssignmentType.MANUAL;
        const data = await distributionService.assignManual(pathParam(req, "id"), body.captainId, req.user.id, mode);
        return res.json(ok(data));
    },
    /** تعيين من لوحة السحب والإفلات — يسجل DRAG_DROP في OrderAssignmentLog */
    dragDropAssign: async (req, res) => {
        const body = req.body;
        const data = await distributionService.assignManual(pathParam(req, "id"), body.captainId, req.user.id, $Enums.AssignmentType.DRAG_DROP);
        return res.json(ok(data));
    },
};
