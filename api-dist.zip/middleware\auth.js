import { verifyAccessToken } from "../lib/jwt.js";
import { HttpError } from "../lib/http-error.js";
export const requireAuth = (req, _res, next) => {
    const header = req.headers.authorization;
    if (!header?.startsWith("Bearer ")) {
        return next(new HttpError(401, "Missing bearer token", "UNAUTHORIZED"));
    }
    const token = header.slice("Bearer ".length);
    try {
        const payload = verifyAccessToken(token);
        req.auth = {
            userId: payload.sub,
            role: payload.role,
            restaurantId: payload.restaurantId,
        };
        return next();
    }
    catch {
        return next(new HttpError(401, "Invalid or expired token", "UNAUTHORIZED"));
    }
};
export function requireRoles(...allowed) {
    return (req, _res, next) => {
        if (!req.auth)
            return next(new HttpError(401, "Unauthorized", "UNAUTHORIZED"));
        if (!allowed.includes(req.auth.role)) {
            return next(new HttpError(403, "Forbidden", "FORBIDDEN"));
        }
        return next();
    };
}
