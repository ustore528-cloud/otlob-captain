import { ok } from "../utils/api-response.js";
import { pathParam } from "../utils/path-params.js";
import { storesService } from "../services/stores.service.js";
export const storesController = {
    create: async (req, res) => {
        const data = await storesService.create(req.body, req.user.id);
        return res.status(201).json(ok(data));
    },
    update: async (req, res) => {
        const data = await storesService.update(pathParam(req, "id"), req.body, req.user.id, { role: req.user.role, userId: req.user.id, storeId: req.user.storeId });
        return res.json(ok(data));
    },
    list: async (req, res) => {
        const q = req.query;
        const data = await storesService.list({
            area: q.area,
            isActive: q.isActive,
            page: Number(q.page) || 1,
            pageSize: Number(q.pageSize) || 20,
        }, { role: req.user.role, userId: req.user.id });
        return res.json(ok(data));
    },
    getById: async (req, res) => {
        const data = await storesService.getById(pathParam(req, "id"), {
            role: req.user.role,
            userId: req.user.id,
        });
        return res.json(ok(data));
    },
};
