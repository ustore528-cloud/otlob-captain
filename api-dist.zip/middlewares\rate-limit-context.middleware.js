/**
 * نقطة تعليق جاهزة لوضع rate limiting (Redis / in-memory).
 * حاليًا لا تطبق أي حدود — لكنها توحّد واجهة الإضافة لاحقًا.
 */
export function rateLimitContextMiddleware(_req, _res, next) {
    // مثال مستقبلي:
    // const key = `${req.ip}:${req.user?.id ?? "anon"}`;
    // await rateLimiter.consume(key);
    return next();
}
