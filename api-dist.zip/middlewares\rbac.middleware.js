import { AppError } from "../utils/errors.js";
export function requireRoles(...allowed) {
    return (req, _res, next) => {
        if (!req.user)
            return next(new AppError(401, "Unauthorized", "UNAUTHORIZED"));
        if (!allowed.includes(req.user.role)) {
            return next(new AppError(403, "Forbidden", "FORBIDDEN"));
        }
        return next();
    };
}
