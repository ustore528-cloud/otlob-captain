import { prisma } from "../lib/prisma.js";
export const orderAssignmentLogRepository = {
    create(data) {
        return prisma.orderAssignmentLog.create({ data });
    },
    findPendingExpiredBefore(date) {
        return prisma.orderAssignmentLog.findMany({
            where: {
                responseStatus: "PENDING",
                expiredAt: { lte: date },
            },
            include: { order: true, captain: true },
        });
    },
    updateStatus(id, responseStatus, notes) {
        return prisma.orderAssignmentLog.update({
            where: { id },
            data: { responseStatus, ...(notes !== undefined ? { notes } : {}) },
        });
    },
    countAutoAttemptsForOrder(orderId) {
        return prisma.orderAssignmentLog.count({
            where: {
                orderId,
                assignmentType: { in: ["AUTO", "REASSIGN"] },
            },
        });
    },
    findLatestForOrder(orderId) {
        return prisma.orderAssignmentLog.findFirst({
            where: { orderId },
            orderBy: { assignedAt: "desc" },
        });
    },
    findPendingForCaptain(orderId, captainId) {
        return prisma.orderAssignmentLog.findFirst({
            where: { orderId, captainId, responseStatus: "PENDING" },
        });
    },
    cancelPendingForOrder(orderId, tx) {
        const client = tx ?? prisma;
        return client.orderAssignmentLog.updateMany({
            where: { orderId, responseStatus: "PENDING" },
            data: { responseStatus: "CANCELLED", notes: "Cancelled by system or user action" },
        });
    },
};
