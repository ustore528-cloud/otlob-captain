import { LoginBodySchema, RegisterUserBodySchema, } from "@captain/shared";
import { prisma } from "../../lib/prisma.js";
import { hashPassword, verifyPassword } from "../../lib/password.js";
import { signAccessToken } from "../../lib/jwt.js";
import { HttpError } from "../../lib/http-error.js";
function toAuthUser(row) {
    return {
        id: row.id,
        email: row.email,
        role: row.role,
        restaurantId: row.restaurantId,
    };
}
export async function login(body) {
    const parsed = LoginBodySchema.parse(body);
    const user = await prisma.user.findUnique({ where: { email: parsed.email } });
    if (!user)
        throw new HttpError(401, "Invalid credentials", "INVALID_CREDENTIALS");
    const ok = await verifyPassword(parsed.password, user.passwordHash);
    if (!ok)
        throw new HttpError(401, "Invalid credentials", "INVALID_CREDENTIALS");
    const accessToken = signAccessToken({
        sub: user.id,
        role: user.role,
        restaurantId: user.restaurantId,
    });
    return { accessToken, user: toAuthUser(user) };
}
export async function register(body) {
    const parsed = RegisterUserBodySchema.parse(body);
    if (parsed.role === "RESTAURANT_STAFF" && !parsed.restaurantId) {
        throw new HttpError(400, "restaurantId required for RESTAURANT_STAFF", "VALIDATION_ERROR");
    }
    if (parsed.restaurantId) {
        const r = await prisma.restaurant.findUnique({ where: { id: parsed.restaurantId } });
        if (!r)
            throw new HttpError(400, "Restaurant not found", "NOT_FOUND");
    }
    const passwordHash = await hashPassword(parsed.password);
    try {
        const user = await prisma.user.create({
            data: {
                email: parsed.email,
                passwordHash,
                role: parsed.role,
                restaurantId: parsed.restaurantId ?? null,
            },
        });
        const accessToken = signAccessToken({
            sub: user.id,
            role: user.role,
            restaurantId: user.restaurantId,
        });
        return { accessToken, user: toAuthUser(user) };
    }
    catch {
        throw new HttpError(409, "Email already registered", "CONFLICT");
    }
}
export async function me(userId) {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user)
        throw new HttpError(404, "User not found", "NOT_FOUND");
    return toAuthUser(user);
}
