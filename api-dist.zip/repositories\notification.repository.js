import { prisma } from "../lib/prisma.js";
export const notificationRepository = {
    create(data) {
        return prisma.notification.create({ data });
    },
    listForUser(userId, params) {
        const where = { userId };
        if (params.isRead !== undefined)
            where.isRead = params.isRead;
        return prisma.$transaction([
            prisma.notification.count({ where }),
            prisma.notification.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip: (params.page - 1) * params.pageSize,
                take: params.pageSize,
            }),
        ]);
    },
    markRead(id, userId) {
        return prisma.notification.updateMany({
            where: { id, userId },
            data: { isRead: true },
        });
    },
    markAllRead(userId) {
        return prisma.notification.updateMany({
            where: { userId, isRead: false },
            data: { isRead: true },
        });
    },
};
