import { Router } from "express";
import { z } from "zod";
import { CreateOrderBodySchema, ManualAssignBodySchema, OrderListQuerySchema, UpdateOrderStatusBodySchema, } from "@captain/shared";
import { requireAuth, requireRoles } from "../../middleware/auth.js";
import { validateBody } from "../../middleware/validate.js";
import { HttpError } from "../../lib/http-error.js";
import * as service from "./order.service.js";
export const orderRouter = Router();
const idParams = z.object({ id: z.string().cuid() });
orderRouter.use(requireAuth);
orderRouter.get("/", async (req, res, next) => {
    try {
        if (req.auth.role === "CAPTAIN") {
            throw new HttpError(403, "Forbidden", "FORBIDDEN");
        }
        const query = OrderListQuerySchema.parse(req.query);
        const result = await service.listOrders(req.auth, query);
        return res.json(result);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.post("/", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER", "RESTAURANT_STAFF"), validateBody(CreateOrderBodySchema), async (req, res, next) => {
    try {
        const created = await service.createOrder(req.auth, req.body);
        return res.status(201).json(created);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.get("/:id", async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.getOrder(req.auth, id);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.patch("/:id/status", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), validateBody(UpdateOrderStatusBodySchema), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.updateOrderStatus(req.auth, id, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.post("/:id/assign/auto", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.assignAuto(req.auth, id);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.post("/:id/assign/manual", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), validateBody(ManualAssignBodySchema), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.assignManual(req.auth, id, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.post("/:id/captain/accept", requireRoles("CAPTAIN"), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.captainAccept(req.auth, id);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
orderRouter.post("/:id/captain/reject", requireRoles("CAPTAIN"), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.captainReject(req.auth, id);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
