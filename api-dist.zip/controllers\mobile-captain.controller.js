import { env } from "../config/env.js";
import { ok } from "../utils/api-response.js";
import { pathParam } from "../utils/path-params.js";
import { captainMobileService } from "../services/captain-mobile.service.js";
import { toOrderDetailDto } from "../dto/order.dto.js";
export const mobileCaptainController = {
    login: async (req, res) => {
        const body = req.body;
        const data = await captainMobileService.login(body);
        return res.json(ok(data));
    },
    refresh: async (req, res) => {
        const body = req.body;
        const tokens = await captainMobileService.refresh(body.refreshToken);
        return res.json(ok({
            ...tokens,
            tokenType: "Bearer",
            expiresIn: env.JWT_ACCESS_EXPIRES_IN,
        }));
    },
    me: async (req, res) => {
        const data = await captainMobileService.me(req.user.id);
        return res.json(ok(data));
    },
    currentAssignment: async (req, res) => {
        const data = await captainMobileService.getCurrentAssignment(req.user.id);
        return res.json(ok(data));
    },
    getOrderById: async (req, res) => {
        const data = await captainMobileService.getOrderById(req.user.id, pathParam(req, "orderId"));
        return res.json(ok(data));
    },
    updateAvailability: async (req, res) => {
        const body = req.body;
        const data = await captainMobileService.updateAvailability(req.user.id, body.availabilityStatus);
        return res.json(ok(data));
    },
    acceptOrder: async (req, res) => {
        const order = await captainMobileService.acceptOrder(pathParam(req, "orderId"), req.user.id);
        return res.json(ok(toOrderDetailDto(order)));
    },
    rejectOrder: async (req, res) => {
        const order = await captainMobileService.rejectOrder(pathParam(req, "orderId"), req.user.id);
        return res.json(ok(order ? toOrderDetailDto(order) : null));
    },
    updateOrderStatus: async (req, res) => {
        const body = req.body;
        const order = await captainMobileService.updateOrderStatus(pathParam(req, "orderId"), body.status, req.user.id);
        return res.json(ok(toOrderDetailDto(order)));
    },
    updateLocation: async (req, res) => {
        const body = req.body;
        const loc = await captainMobileService.updateLocation(req.user.id, body.latitude, body.longitude);
        return res.json(ok({
            id: loc.id,
            captainId: loc.captainId,
            latitude: loc.latitude,
            longitude: loc.longitude,
            recordedAt: loc.recordedAt.toISOString(),
        }));
    },
    orderHistory: async (req, res) => {
        const q = req.query;
        const data = await captainMobileService.orderHistory(req.user.id, q);
        return res.json(ok(data));
    },
    earningsSummary: async (req, res) => {
        const q = req.query;
        const data = await captainMobileService.earningsSummary(req.user.id, q);
        return res.json(ok(data));
    },
};
