function dec(v) {
    if (v == null)
        return "0";
    return v.toString();
}
export function toOrderDetailDto(order) {
    return {
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        pickupAddress: order.pickupAddress,
        dropoffAddress: order.dropoffAddress,
        area: order.area,
        amount: dec(order.amount),
        cashCollection: dec(order.cashCollection),
        notes: order.notes,
        store: {
            id: order.store.id,
            name: order.store.name,
            area: order.store.area,
            ...(order.store.phone != null ? { phone: order.store.phone } : {}),
        },
        createdAt: order.createdAt.toISOString(),
        updatedAt: order.updatedAt.toISOString(),
        assignmentLogs: (order.assignmentLogs ?? []).map((l) => ({
            id: l.id,
            captainId: l.captainId,
            assignmentType: l.assignmentType,
            assignedAt: l.assignedAt.toISOString(),
            responseStatus: l.responseStatus,
            expiredAt: l.expiredAt ? l.expiredAt.toISOString() : null,
            notes: l.notes,
        })),
    };
}
export function toOrderListItemDto(order) {
    return {
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        area: order.area,
        amount: dec(order.amount),
        cashCollection: dec(order.cashCollection),
        store: { id: order.store.id, name: order.store.name, area: order.store.area },
        createdAt: order.createdAt.toISOString(),
        updatedAt: order.updatedAt.toISOString(),
    };
}
