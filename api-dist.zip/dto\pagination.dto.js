export function buildPaginationMeta(page, pageSize, total) {
    const totalPages = pageSize > 0 ? Math.ceil(total / pageSize) : 0;
    return { page, pageSize, total, totalPages };
}
export function buildPaginatedDto(items, page, pageSize, total) {
    return {
        items,
        pagination: buildPaginationMeta(page, pageSize, total),
    };
}
