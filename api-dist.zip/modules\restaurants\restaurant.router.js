import { Router } from "express";
import { z } from "zod";
import { CreateRestaurantBodySchema, UpdateRestaurantBodySchema, } from "@captain/shared";
import { requireAuth, requireRoles } from "../../middleware/auth.js";
import { validateBody } from "../../middleware/validate.js";
import { HttpError } from "../../lib/http-error.js";
import * as service from "./restaurant.service.js";
export const restaurantRouter = Router();
const idParams = z.object({ id: z.string().cuid() });
restaurantRouter.use(requireAuth);
restaurantRouter.get("/", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER", "RESTAURANT_STAFF"), async (req, res, next) => {
    try {
        if (req.auth.role === "RESTAURANT_STAFF") {
            if (!req.auth.restaurantId)
                throw new HttpError(400, "Missing restaurant scope", "BAD_REQUEST");
            const one = await service.getRestaurant(req.auth.restaurantId);
            return res.json({ items: [one] });
        }
        const items = await service.listRestaurants();
        return res.json({ items });
    }
    catch (e) {
        return next(e);
    }
});
restaurantRouter.post("/", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), validateBody(CreateRestaurantBodySchema), async (req, res, next) => {
    try {
        const created = await service.createRestaurant(req.body);
        return res.status(201).json(created);
    }
    catch (e) {
        return next(e);
    }
});
restaurantRouter.get("/:id", async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        if (req.auth.role === "RESTAURANT_STAFF" && req.auth.restaurantId !== id) {
            throw new HttpError(403, "Forbidden", "FORBIDDEN");
        }
        const row = await service.getRestaurant(id);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
restaurantRouter.patch("/:id", requireRoles("SUPER_ADMIN", "ADMIN", "DISPATCHER"), validateBody(UpdateRestaurantBodySchema), async (req, res, next) => {
    try {
        const { id } = idParams.parse(req.params);
        const row = await service.updateRestaurant(id, req.body);
        return res.json(row);
    }
    catch (e) {
        return next(e);
    }
});
