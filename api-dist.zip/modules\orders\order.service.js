import { prisma } from "../../lib/prisma.js";
import { HttpError } from "../../lib/http-error.js";
import { emitOrderCreated, emitOrderUpdated, emitToCaptain } from "../../realtime/hub.js";
function assignmentToDto(a) {
    return {
        id: a.id,
        orderId: a.orderId,
        captainId: a.captainId,
        method: a.method,
        status: a.status,
        assignedAt: a.assignedAt.toISOString(),
        acceptedAt: a.acceptedAt ? a.acceptedAt.toISOString() : null,
    };
}
function orderToDto(o, assignments) {
    return {
        id: o.id,
        restaurantId: o.restaurantId,
        status: o.status,
        pickupAddress: o.pickupAddress,
        deliveryAddress: o.deliveryAddress,
        pickupLatitude: o.pickupLatitude,
        pickupLongitude: o.pickupLongitude,
        deliveryLatitude: o.deliveryLatitude,
        deliveryLongitude: o.deliveryLongitude,
        notes: o.notes,
        createdById: o.createdById,
        createdAt: o.createdAt.toISOString(),
        updatedAt: o.updatedAt.toISOString(),
        assignments,
    };
}
async function requireOrderVisible(auth, orderId) {
    const order = await prisma.order.findUnique({
        where: { id: orderId },
        include: { assignments: { orderBy: { assignedAt: "desc" } } },
    });
    if (!order)
        throw new HttpError(404, "Order not found", "NOT_FOUND");
    if (auth.role === "RESTAURANT_STAFF") {
        if (!auth.restaurantId || order.restaurantId !== auth.restaurantId) {
            throw new HttpError(403, "Forbidden", "FORBIDDEN");
        }
    }
    if (auth.role === "CAPTAIN") {
        const profile = await prisma.captainProfile.findUnique({ where: { userId: auth.userId } });
        if (!profile)
            throw new HttpError(403, "Forbidden", "FORBIDDEN");
        const allowed = order.assignments.some((a) => a.captainId === profile.id);
        if (!allowed)
            throw new HttpError(403, "Forbidden", "FORBIDDEN");
    }
    return order;
}
export async function createOrder(auth, body) {
    let restaurantId = body.restaurantId;
    if (auth.role === "RESTAURANT_STAFF") {
        if (!auth.restaurantId)
            throw new HttpError(400, "Missing restaurant scope", "BAD_REQUEST");
        restaurantId = auth.restaurantId;
    }
    else if (!["SUPER_ADMIN", "ADMIN", "DISPATCHER"].includes(auth.role)) {
        throw new HttpError(403, "Forbidden", "FORBIDDEN");
    }
    const restaurant = await prisma.restaurant.findUnique({ where: { id: restaurantId } });
    if (!restaurant)
        throw new HttpError(400, "Restaurant not found", "NOT_FOUND");
    const order = await prisma.order.create({
        data: {
            restaurantId,
            pickupAddress: body.pickupAddress,
            deliveryAddress: body.deliveryAddress,
            pickupLatitude: body.pickupLatitude ?? null,
            pickupLongitude: body.pickupLongitude ?? null,
            deliveryLatitude: body.deliveryLatitude ?? null,
            deliveryLongitude: body.deliveryLongitude ?? null,
            notes: body.notes ?? null,
            createdById: auth.userId,
            status: "PENDING",
        },
        include: { assignments: true },
    });
    const dto = orderToDto(order, order.assignments.map(assignmentToDto));
    emitOrderCreated(dto);
    emitOrderUpdated(dto);
    return dto;
}
export async function listOrders(auth, query) {
    const where = {};
    if (auth.role === "RESTAURANT_STAFF") {
        if (!auth.restaurantId)
            throw new HttpError(400, "Missing restaurant scope", "BAD_REQUEST");
        where.restaurantId = auth.restaurantId;
    }
    else if (query.restaurantId) {
        where.restaurantId = query.restaurantId;
    }
    if (query.status)
        where.status = query.status;
    const [total, rows] = await prisma.$transaction([
        prisma.order.count({ where }),
        prisma.order.findMany({
            where,
            orderBy: { createdAt: "desc" },
            skip: (query.page - 1) * query.pageSize,
            take: query.pageSize,
            include: { assignments: { orderBy: { assignedAt: "desc" } } },
        }),
    ]);
    return {
        total,
        items: rows.map((o) => orderToDto(o, o.assignments.map(assignmentToDto))),
    };
}
export async function getOrder(auth, orderId) {
    const order = await requireOrderVisible(auth, orderId);
    return orderToDto(order, order.assignments.map(assignmentToDto));
}
export async function updateOrderStatus(auth, orderId, body) {
    if (!["SUPER_ADMIN", "ADMIN", "DISPATCHER"].includes(auth.role)) {
        throw new HttpError(403, "Forbidden", "FORBIDDEN");
    }
    await requireOrderVisible(auth, orderId);
    const order = await prisma.order.update({
        where: { id: orderId },
        data: { status: body.status },
        include: { assignments: { orderBy: { assignedAt: "desc" } } },
    });
    const dto = orderToDto(order, order.assignments.map(assignmentToDto));
    emitOrderUpdated(dto);
    return dto;
}
async function pickCaptainForAutoDispatch(tx) {
    const captains = await tx.captainProfile.findMany({
        where: { isActive: true },
        include: {
            assignments: {
                where: {
                    status: { in: ["PENDING", "ACCEPTED"] },
                    order: { status: { notIn: ["DELIVERED", "CANCELLED"] } },
                },
            },
        },
    });
    if (captains.length === 0) {
        throw new HttpError(409, "No active captains available", "NO_ACTIVE_CAPTAINS");
    }
    captains.sort((a, b) => a.assignments.length - b.assignments.length || a.updatedAt.getTime() - b.updatedAt.getTime());
    const pick = captains[0];
    return { id: pick.id, userId: pick.userId };
}
export async function assignAuto(auth, orderId) {
    if (!["SUPER_ADMIN", "ADMIN", "DISPATCHER"].includes(auth.role)) {
        throw new HttpError(403, "Forbidden", "FORBIDDEN");
    }
    const existing = await requireOrderVisible(auth, orderId);
    if (existing.status !== "PENDING") {
        throw new HttpError(409, "Order is not pending dispatch", "INVALID_STATE");
    }
    const dto = await prisma.$transaction(async (tx) => {
        await tx.orderAssignment.updateMany({
            where: { orderId, status: "PENDING" },
            data: { status: "CANCELLED" },
        });
        const captain = await pickCaptainForAutoDispatch(tx);
        await tx.orderAssignment.create({
            data: {
                orderId,
                captainId: captain.id,
                method: "AUTO",
                status: "PENDING",
            },
        });
        const order = await tx.order.update({
            where: { id: orderId },
            data: { status: "ASSIGNED" },
            include: { assignments: { orderBy: { assignedAt: "desc" } } },
        });
        return orderToDto(order, order.assignments.map(assignmentToDto));
    });
    emitOrderUpdated(dto);
    const pending = await prisma.orderAssignment.findFirst({
        where: { orderId, status: "PENDING" },
        include: { captain: true },
    });
    if (pending?.captain?.userId) {
        emitToCaptain(pending.captain.userId, "order:offer", dto);
    }
    return dto;
}
export async function assignManual(auth, orderId, body) {
    if (!["SUPER_ADMIN", "ADMIN", "DISPATCHER"].includes(auth.role)) {
        throw new HttpError(403, "Forbidden", "FORBIDDEN");
    }
    const existing = await requireOrderVisible(auth, orderId);
    if (existing.status !== "PENDING") {
        throw new HttpError(409, "Order is not pending dispatch", "INVALID_STATE");
    }
    const captain = await prisma.captainProfile.findUnique({ where: { id: body.captainId } });
    if (!captain)
        throw new HttpError(400, "Captain not found", "NOT_FOUND");
    if (!captain.isActive)
        throw new HttpError(409, "Captain is not active", "CAPTAIN_INACTIVE");
    const dto = await prisma.$transaction(async (tx) => {
        await tx.orderAssignment.updateMany({
            where: { orderId, status: "PENDING" },
            data: { status: "CANCELLED" },
        });
        await tx.orderAssignment.create({
            data: {
                orderId,
                captainId: captain.id,
                method: "MANUAL",
                status: "PENDING",
            },
        });
        const order = await tx.order.update({
            where: { id: orderId },
            data: { status: "ASSIGNED" },
            include: { assignments: { orderBy: { assignedAt: "desc" } } },
        });
        return orderToDto(order, order.assignments.map(assignmentToDto));
    });
    emitOrderUpdated(dto);
    emitToCaptain(captain.userId, "order:offer", dto);
    return dto;
}
export async function captainAccept(auth, orderId) {
    if (auth.role !== "CAPTAIN")
        throw new HttpError(403, "Forbidden", "FORBIDDEN");
    const profile = await prisma.captainProfile.findUnique({ where: { userId: auth.userId } });
    if (!profile)
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    const dto = await prisma.$transaction(async (tx) => {
        const assignment = await tx.orderAssignment.findFirst({
            where: { orderId, captainId: profile.id, status: "PENDING" },
        });
        if (!assignment)
            throw new HttpError(409, "No pending assignment for this order", "INVALID_STATE");
        await tx.orderAssignment.updateMany({
            where: { orderId, status: "PENDING", id: { not: assignment.id } },
            data: { status: "CANCELLED" },
        });
        await tx.orderAssignment.update({
            where: { id: assignment.id },
            data: { status: "ACCEPTED", acceptedAt: new Date() },
        });
        const order = await tx.order.update({
            where: { id: orderId },
            data: { status: "ACCEPTED" },
            include: { assignments: { orderBy: { assignedAt: "desc" } } },
        });
        return orderToDto(order, order.assignments.map(assignmentToDto));
    });
    emitOrderUpdated(dto);
    return dto;
}
export async function captainReject(auth, orderId) {
    if (auth.role !== "CAPTAIN")
        throw new HttpError(403, "Forbidden", "FORBIDDEN");
    const profile = await prisma.captainProfile.findUnique({ where: { userId: auth.userId } });
    if (!profile)
        throw new HttpError(404, "Captain profile not found", "NOT_FOUND");
    const dto = await prisma.$transaction(async (tx) => {
        const assignment = await tx.orderAssignment.findFirst({
            where: { orderId, captainId: profile.id, status: "PENDING" },
        });
        if (!assignment)
            throw new HttpError(409, "No pending assignment for this order", "INVALID_STATE");
        await tx.orderAssignment.update({
            where: { id: assignment.id },
            data: { status: "REJECTED" },
        });
        const order = await tx.order.update({
            where: { id: orderId },
            data: { status: "PENDING" },
            include: { assignments: { orderBy: { assignedAt: "desc" } } },
        });
        return orderToDto(order, order.assignments.map(assignmentToDto));
    });
    emitOrderUpdated(dto);
    return dto;
}
