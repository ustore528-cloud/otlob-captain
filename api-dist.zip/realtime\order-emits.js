import { CAPTAIN_SOCKET_EVENTS } from "./captain-events.js";
import { emitOrderUpdated, emitToCaptain } from "./hub.js";
export function emitDispatcherOrderUpdated(order) {
    emitOrderUpdated({
        id: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
    });
}
export function emitCaptainOrderUpdated(captainUserId, order) {
    emitToCaptain(captainUserId, CAPTAIN_SOCKET_EVENTS.ORDER_UPDATED, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
    });
}
export function emitCaptainAssignmentEnded(captainUserId, payload) {
    emitToCaptain(captainUserId, CAPTAIN_SOCKET_EVENTS.ASSIGNMENT_ENDED, payload);
}
