import { activityLogRepository } from "../repositories/activity-log.repository.js";
export const activityReadService = {
    list(params) {
        return activityLogRepository.list(params);
    },
};
