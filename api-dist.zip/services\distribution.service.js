import { AssignmentType, AssignmentResponseStatus, OrderStatus, CaptainAvailabilityStatus, DistributionMode, } from "@prisma/client";
import { prisma } from "../lib/prisma.js";
import { env } from "../config/env.js";
import { AppError } from "../utils/errors.js";
import { activityService } from "./activity.service.js";
import { notificationService } from "./notifications.service.js";
function expiredAtFromNow() {
    return new Date(Date.now() + env.DISTRIBUTION_TIMEOUT_SECONDS * 1000);
}
async function assignNextCaptainTx(tx, orderId, assignmentType, actorUserId) {
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order)
        throw new AppError(404, "Order not found", "NOT_FOUND");
    const captains = await tx.captain.findMany({
        where: {
            isActive: true,
            availabilityStatus: CaptainAvailabilityStatus.AVAILABLE,
            user: { isActive: true },
        },
        orderBy: { id: "asc" },
    });
    if (captains.length === 0) {
        await tx.order.update({
            where: { id: orderId },
            data: { status: OrderStatus.PENDING, assignedCaptainId: null },
        });
        await activityService.logTx(tx, actorUserId, "DISTRIBUTION_NO_CAPTAINS", "order", orderId, {});
        return null;
    }
    const resetAt = order.lastDistributionResetAt ?? order.createdAt;
    const rounds = await tx.orderAssignmentLog.count({
        where: {
            orderId,
            assignmentType: { in: [AssignmentType.AUTO, AssignmentType.REASSIGN] },
            responseStatus: {
                in: [AssignmentResponseStatus.EXPIRED, AssignmentResponseStatus.REJECTED],
            },
            assignedAt: { gte: resetAt },
        },
    });
    if (rounds >= env.DISTRIBUTION_MAX_ATTEMPTS) {
        await tx.order.update({
            where: { id: orderId },
            data: { status: OrderStatus.PENDING, assignedCaptainId: null },
        });
        await activityService.logTx(tx, actorUserId, "DISTRIBUTION_EXHAUSTED", "order", orderId, { rounds });
        return null;
    }
    const captain = captains[rounds % captains.length];
    await tx.orderAssignmentLog.create({
        data: {
            orderId,
            captainId: captain.id,
            assignmentType,
            responseStatus: AssignmentResponseStatus.PENDING,
            expiredAt: expiredAtFromNow(),
        },
    });
    await tx.order.update({
        where: { id: orderId },
        data: {
            status: OrderStatus.ASSIGNED,
            assignedCaptainId: captain.id,
        },
    });
    await notificationService.notifyCaptainTx(tx, captain.userId, "ORDER_ASSIGNED", "تعيين طلب", `طلب ${order.orderNumber} — يرجى الرد خلال ${env.DISTRIBUTION_TIMEOUT_SECONDS} ثانية`);
    await activityService.logTx(tx, actorUserId, "ORDER_ASSIGNED_CAPTAIN", "order", orderId, {
        captainId: captain.id,
        assignmentType,
    });
    return captain;
}
export const distributionService = {
    /** بعد رفض الكابتن: إما سلسلة توزيع تلقائي أو إرجاع للانتظار */
    async afterCaptainRejectTx(tx, orderId, actorUserId) {
        const order = await tx.order.findUnique({ where: { id: orderId } });
        if (!order)
            return;
        if (order.distributionMode === "AUTO") {
            await assignNextCaptainTx(tx, orderId, AssignmentType.AUTO, actorUserId);
        }
        else {
            await tx.order.update({
                where: { id: orderId },
                data: { status: OrderStatus.PENDING, assignedCaptainId: null },
            });
        }
    },
    async tickExpired() {
        const now = new Date();
        const logs = await prisma.orderAssignmentLog.findMany({
            where: {
                responseStatus: AssignmentResponseStatus.PENDING,
                expiredAt: { lte: now },
            },
            select: { id: true, orderId: true },
        });
        for (const log of logs) {
            try {
                await prisma.$transaction(async (tx) => {
                    const current = await tx.orderAssignmentLog.findUnique({ where: { id: log.id } });
                    if (!current || current.responseStatus !== AssignmentResponseStatus.PENDING)
                        return;
                    await tx.orderAssignmentLog.update({
                        where: { id: log.id },
                        data: { responseStatus: AssignmentResponseStatus.EXPIRED },
                    });
                    const order = await tx.order.findUnique({ where: { id: log.orderId } });
                    if (!order)
                        return;
                    if (order.distributionMode === DistributionMode.AUTO && order.status === OrderStatus.ASSIGNED) {
                        await assignNextCaptainTx(tx, log.orderId, AssignmentType.AUTO, null);
                        return;
                    }
                    await tx.order.update({
                        where: { id: log.orderId },
                        data: { status: OrderStatus.PENDING, assignedCaptainId: null },
                    });
                });
            }
            catch (e) {
                console.error("distribution tick", log.id, e);
            }
        }
    },
    async startAuto(orderId, actorUserId) {
        return prisma.$transaction(async (tx) => {
            const order = await tx.order.findUnique({ where: { id: orderId } });
            if (!order)
                throw new AppError(404, "Order not found", "NOT_FOUND");
            if (order.distributionMode !== DistributionMode.AUTO) {
                throw new AppError(400, "Order distribution mode is not AUTO", "INVALID_STATE");
            }
            if (order.status !== OrderStatus.PENDING && order.status !== OrderStatus.CONFIRMED) {
                throw new AppError(409, "Order is not awaiting auto distribution", "INVALID_STATE");
            }
            await tx.orderAssignmentLog.updateMany({
                where: { orderId, responseStatus: AssignmentResponseStatus.PENDING },
                data: {
                    responseStatus: AssignmentResponseStatus.CANCELLED,
                    notes: "Cancelled: restart auto distribution",
                },
            });
            await tx.order.update({
                where: { id: orderId },
                data: { lastDistributionResetAt: new Date() },
            });
            await assignNextCaptainTx(tx, orderId, AssignmentType.AUTO, actorUserId);
            return tx.order.findUnique({
                where: { id: orderId },
                include: {
                    store: { select: { id: true, name: true } },
                    assignedCaptain: { include: { user: { select: { id: true, fullName: true, phone: true } } } },
                    assignmentLogs: { orderBy: { assignedAt: "desc" }, take: 15 },
                },
            });
        });
    },
    async resendToDistribution(orderId, actorUserId) {
        return prisma.$transaction(async (tx) => {
            const order = await tx.order.findUnique({ where: { id: orderId } });
            if (!order)
                throw new AppError(404, "Order not found", "NOT_FOUND");
            await tx.orderAssignmentLog.updateMany({
                where: { orderId, responseStatus: AssignmentResponseStatus.PENDING },
                data: {
                    responseStatus: AssignmentResponseStatus.CANCELLED,
                    notes: "Cancelled: resend to distribution",
                },
            });
            await tx.order.update({
                where: { id: orderId },
                data: {
                    status: OrderStatus.PENDING,
                    assignedCaptainId: null,
                    distributionMode: DistributionMode.AUTO,
                    lastDistributionResetAt: new Date(),
                },
            });
            await activityService.logTx(tx, actorUserId, "ORDER_RESEND_DISTRIBUTION", "order", orderId, {});
            await assignNextCaptainTx(tx, orderId, AssignmentType.AUTO, actorUserId);
            return tx.order.findUnique({
                where: { id: orderId },
                include: {
                    store: { select: { id: true, name: true } },
                    assignedCaptain: { include: { user: { select: { id: true, fullName: true, phone: true } } } },
                    assignmentLogs: { orderBy: { assignedAt: "desc" }, take: 15 },
                },
            });
        });
    },
    async assignManual(orderId, captainId, actorUserId) {
        return prisma.$transaction(async (tx) => {
            const order = await tx.order.findUnique({ where: { id: orderId } });
            if (!order)
                throw new AppError(404, "Order not found", "NOT_FOUND");
            if (order.status !== OrderStatus.PENDING &&
                order.status !== OrderStatus.CONFIRMED &&
                order.status !== OrderStatus.ASSIGNED) {
                throw new AppError(409, "Cannot assign order in current status", "INVALID_STATE");
            }
            const captain = await tx.captain.findUnique({
                where: { id: captainId },
                include: { user: true },
            });
            if (!captain || !captain.isActive || !captain.user.isActive) {
                throw new AppError(400, "Captain not available", "CAPTAIN_UNAVAILABLE");
            }
            await tx.orderAssignmentLog.updateMany({
                where: { orderId, responseStatus: AssignmentResponseStatus.PENDING },
                data: {
                    responseStatus: AssignmentResponseStatus.CANCELLED,
                    notes: "Cancelled: manual assign",
                },
            });
            await tx.orderAssignmentLog.create({
                data: {
                    orderId,
                    captainId: captain.id,
                    assignmentType: AssignmentType.MANUAL,
                    responseStatus: AssignmentResponseStatus.PENDING,
                    expiredAt: expiredAtFromNow(),
                },
            });
            await tx.order.update({
                where: { id: orderId },
                data: {
                    status: OrderStatus.ASSIGNED,
                    assignedCaptainId: captain.id,
                    distributionMode: DistributionMode.MANUAL,
                },
            });
            await notificationService.notifyCaptainTx(tx, captain.userId, "ORDER_ASSIGNED", "تعيين يدوي", `تم تعيينك يدويًا للطلب ${order.orderNumber}`);
            await activityService.logTx(tx, actorUserId, "ORDER_MANUAL_ASSIGN", "order", orderId, { captainId });
            return tx.order.findUnique({
                where: { id: orderId },
                include: {
                    store: true,
                    assignedCaptain: { include: { user: { select: { id: true, fullName: true, phone: true } } } },
                    assignmentLogs: { orderBy: { assignedAt: "desc" }, take: 15 },
                },
            });
        });
    },
    async reassign(orderId, captainId, actorUserId) {
        return prisma.$transaction(async (tx) => {
            const order = await tx.order.findUnique({ where: { id: orderId } });
            if (!order)
                throw new AppError(404, "Order not found", "NOT_FOUND");
            const captain = await tx.captain.findUnique({
                where: { id: captainId },
                include: { user: true },
            });
            if (!captain || !captain.isActive || !captain.user.isActive) {
                throw new AppError(400, "Captain not available", "CAPTAIN_UNAVAILABLE");
            }
            await tx.orderAssignmentLog.updateMany({
                where: { orderId, responseStatus: AssignmentResponseStatus.PENDING },
                data: {
                    responseStatus: AssignmentResponseStatus.CANCELLED,
                    notes: "Cancelled: reassign",
                },
            });
            await tx.orderAssignmentLog.create({
                data: {
                    orderId,
                    captainId: captain.id,
                    assignmentType: AssignmentType.REASSIGN,
                    responseStatus: AssignmentResponseStatus.PENDING,
                    expiredAt: expiredAtFromNow(),
                },
            });
            await tx.order.update({
                where: { id: orderId },
                data: {
                    status: OrderStatus.ASSIGNED,
                    assignedCaptainId: captain.id,
                },
            });
            await notificationService.notifyCaptainTx(tx, captain.userId, "ORDER_REASSIGNED", "إعادة تعيين", `تم إعادة تعيينك للطلب ${order.orderNumber}`);
            await activityService.logTx(tx, actorUserId, "ORDER_REASSIGNED", "order", orderId, { captainId });
            return tx.order.findUnique({
                where: { id: orderId },
                include: {
                    store: true,
                    assignedCaptain: { include: { user: { select: { id: true, fullName: true, phone: true } } } },
                    assignmentLogs: { orderBy: { assignedAt: "desc" }, take: 15 },
                },
            });
        });
    },
};
