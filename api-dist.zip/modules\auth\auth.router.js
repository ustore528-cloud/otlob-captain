import { Router } from "express";
import { LoginBodySchema, RegisterUserBodySchema } from "@captain/shared";
import { requireAuth } from "../../middleware/auth.js";
import { validateBody } from "../../middleware/validate.js";
import * as authService from "./auth.service.js";
export const authRouter = Router();
authRouter.post("/login", validateBody(LoginBodySchema), async (req, res, next) => {
    try {
        const result = await authService.login(req.body);
        return res.json(result);
    }
    catch (e) {
        return next(e);
    }
});
authRouter.post("/register", validateBody(RegisterUserBodySchema), async (req, res, next) => {
    try {
        const result = await authService.register(req.body);
        return res.status(201).json(result);
    }
    catch (e) {
        return next(e);
    }
});
authRouter.get("/me", requireAuth, async (req, res, next) => {
    try {
        const user = await authService.me(req.auth.userId);
        return res.json({ user });
    }
    catch (e) {
        return next(e);
    }
});
