import { ok } from "../utils/api-response.js";
import { pathParam } from "../utils/path-params.js";
import { notificationService } from "../services/notifications.service.js";
export const notificationsController = {
    create: async (req, res) => {
        const payload = req.body;
        const data = await notificationService.create(payload.userId, payload.type, payload.title, payload.message, req.user.id);
        return res.status(201).json(ok(data));
    },
    listMine: async (req, res) => {
        const q = req.query;
        const data = await notificationService.list(req.user.id, {
            page: Number(q.page) || 1,
            pageSize: Number(q.pageSize) || 20,
            isRead: q.isRead === undefined ? undefined : q.isRead === "true",
        });
        return res.json(ok(data));
    },
    markRead: async (req, res) => {
        await notificationService.markRead(pathParam(req, "id"), req.user.id);
        return res.json(ok({ ok: true }));
    },
    markAllRead: async (req, res) => {
        await notificationService.markAllRead(req.user.id);
        return res.json(ok({ ok: true }));
    },
    quickStatusAlert: async (req, res) => {
        const payload = req.body;
        const data = await notificationService.sendQuickStatusAlert(payload.status, req.user.id);
        return res.status(201).json(ok(data));
    },
};
