import { prisma } from "../lib/prisma.js";
export const orderRepository = {
    findById(id) {
        return prisma.order.findUnique({
            where: { id },
            include: {
                store: true,
                assignedCaptain: { include: { user: { select: { id: true, fullName: true, phone: true } } } },
                assignmentLogs: { orderBy: { assignedAt: "desc" }, take: 50 },
                createdBy: { select: { id: true, fullName: true, phone: true } },
            },
        });
    },
    create(data) {
        return prisma.order.create({
            data,
            include: {
                store: true,
                assignedCaptain: true,
                createdBy: { select: { id: true, fullName: true, phone: true } },
            },
        });
    },
    update(id, data) {
        return prisma.order.update({
            where: { id },
            data,
            include: {
                store: true,
                assignedCaptain: { include: { user: { select: { id: true, fullName: true, phone: true } } } },
                assignmentLogs: { orderBy: { assignedAt: "desc" }, take: 20 },
            },
        });
    },
    list(params) {
        const where = {};
        if (params.storeId)
            where.storeId = params.storeId;
        if (params.status)
            where.status = params.status;
        if (params.area)
            where.area = { contains: params.area, mode: "insensitive" };
        if (params.orderNumber)
            where.orderNumber = { contains: params.orderNumber, mode: "insensitive" };
        if (params.customerPhone)
            where.customerPhone = { contains: params.customerPhone };
        return prisma.$transaction([
            prisma.order.count({ where }),
            prisma.order.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip: (params.page - 1) * params.pageSize,
                take: params.pageSize,
                include: {
                    store: { select: { id: true, name: true, area: true } },
                    assignedCaptain: {
                        include: { user: { select: { fullName: true, phone: true } } },
                    },
                },
            }),
        ]);
    },
    listForCaptain(params) {
        const AND = [
            {
                OR: [
                    { assignedCaptainId: params.captainId },
                    { assignmentLogs: { some: { captainId: params.captainId } } },
                ],
            },
        ];
        if (params.status)
            AND.push({ status: params.status });
        if (params.from || params.to) {
            const createdAt = {};
            if (params.from)
                createdAt.gte = params.from;
            if (params.to)
                createdAt.lte = params.to;
            AND.push({ createdAt });
        }
        const areaTrim = params.area?.trim();
        if (areaTrim)
            AND.push({ area: { contains: areaTrim, mode: "insensitive" } });
        const qTrim = params.q?.trim();
        if (qTrim) {
            AND.push({
                OR: [
                    { orderNumber: { contains: qTrim, mode: "insensitive" } },
                    { customerName: { contains: qTrim, mode: "insensitive" } },
                    { customerPhone: { contains: qTrim, mode: "insensitive" } },
                    { pickupAddress: { contains: qTrim, mode: "insensitive" } },
                    { dropoffAddress: { contains: qTrim, mode: "insensitive" } },
                    { area: { contains: qTrim, mode: "insensitive" } },
                ],
            });
        }
        const where = { AND };
        return prisma.$transaction([
            prisma.order.count({ where }),
            prisma.order.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip: (params.page - 1) * params.pageSize,
                take: params.pageSize,
                include: {
                    store: { select: { id: true, name: true, area: true } },
                    assignedCaptain: {
                        include: { user: { select: { id: true, fullName: true, phone: true } } },
                    },
                },
            }),
        ]);
    },
};
