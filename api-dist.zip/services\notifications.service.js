import { prisma } from "../lib/prisma.js";
import { notificationRepository } from "../repositories/notification.repository.js";
import { activityService } from "./activity.service.js";
const QUICK_STATUS_LABEL = {
    PRESSURE: "ضغط",
    LOW_ACTIVITY: "حركة ضعيفة",
    RAISE_READINESS: "ارفع الجاهزية",
    ON_FIRE: "الوضع نار",
};
export const notificationService = {
    async create(userId, type, title, body, actorUserId) {
        const row = await notificationRepository.create({
            user: { connect: { id: userId } },
            type,
            title,
            body,
        });
        if (actorUserId) {
            await activityService.log(actorUserId, "NOTIFICATION_CREATED", "notification", row.id, { targetUserId: userId });
        }
        return row;
    },
    async notifyCaptainTx(tx, captainUserId, type, title, body) {
        return tx.notification.create({
            data: { userId: captainUserId, type, title, body },
        });
    },
    list(userId, params) {
        return notificationRepository.listForUser(userId, params);
    },
    markRead(id, userId) {
        return notificationRepository.markRead(id, userId);
    },
    markAllRead(userId) {
        return notificationRepository.markAllRead(userId);
    },
    async sendQuickStatusAlert(status, actorUserId) {
        const label = QUICK_STATUS_LABEL[status];
        const captains = await prisma.captain.findMany({
            where: { isActive: true, user: { isActive: true } },
            select: { userId: true },
        });
        if (captains.length === 0) {
            await activityService.log(actorUserId, "QUICK_STATUS_ALERT", "notification", "none", { status, label, count: 0 });
            return { status, label, sent: 0 };
        }
        await prisma.notification.createMany({
            data: captains.map((c) => ({
                userId: c.userId,
                type: "QUICK_STATUS_ALERT",
                title: `تنبيه التشغيل: ${label}`,
                body: `حالة الشغل الآن: ${label}`,
            })),
        });
        await activityService.log(actorUserId, "QUICK_STATUS_ALERT", "notification", status, {
            status,
            label,
            count: captains.length,
        });
        return { status, label, sent: captains.length };
    },
};
