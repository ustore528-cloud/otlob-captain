import { ok } from "../utils/api-response.js";
import { pathParam } from "../utils/path-params.js";
import { usersService } from "../services/users.service.js";
export const usersController = {
    list: async (req, res) => {
        const q = req.query;
        const data = await usersService.list({
            role: q.role,
            page: Number(q.page) || 1,
            pageSize: Number(q.pageSize) || 20,
        });
        return res.json(ok(data));
    },
    getById: async (req, res) => {
        const data = await usersService.getById(pathParam(req, "id"));
        return res.json(ok(data));
    },
    setActive: async (req, res) => {
        const body = req.body;
        const data = await usersService.setActive(pathParam(req, "id"), body.isActive, req.user.id);
        return res.json(ok(data));
    },
    create: async (req, res) => {
        const data = await usersService.create(req.body, req.user.id);
        return res.status(201).json(ok(data));
    },
    updateCustomerProfile: async (req, res) => {
        const data = await usersService.updateCustomerProfile(pathParam(req, "id"), req.body);
        return res.json(ok(data));
    },
};
