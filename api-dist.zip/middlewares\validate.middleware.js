export function validate(part, schema) {
    return (req, _res, next) => {
        const source = part === "body" ? req.body : part === "query" ? req.query : req.params;
        const parsed = schema.safeParse(source);
        if (!parsed.success)
            return next(parsed.error);
        if (part === "body")
            req.body = parsed.data;
        if (part === "query")
            Object.assign(req.query, parsed.data);
        if (part === "params")
            Object.assign(req.params, parsed.data);
        next();
    };
}
