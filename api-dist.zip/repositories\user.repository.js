import { prisma } from "../lib/prisma.js";
const userPublicSelect = {
    id: true,
    fullName: true,
    phone: true,
    email: true,
    role: true,
    isActive: true,
    createdAt: true,
    updatedAt: true,
    customerPickupAddress: true,
    customerDropoffAddress: true,
    customerLocationLink: true,
    customerArea: true,
    customerDropoffLat: true,
    customerDropoffLng: true,
    customerPreferredAmount: true,
    customerPreferredDelivery: true,
};
export const userRepository = {
    findById(id) {
        return prisma.user.findUnique({ where: { id } });
    },
    findByPhone(phone) {
        return prisma.user.findUnique({ where: { phone } });
    },
    findByEmail(email) {
        return prisma.user.findUnique({ where: { email } });
    },
    list(params) {
        const where = {};
        if (params.role)
            where.role = params.role;
        return prisma.$transaction([
            prisma.user.count({ where }),
            prisma.user.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip: (params.page - 1) * params.pageSize,
                take: params.pageSize,
                select: userPublicSelect,
            }),
        ]);
    },
    updateActive(id, isActive) {
        return prisma.user.update({
            where: { id },
            data: { isActive },
            select: userPublicSelect,
        });
    },
    updateCustomerProfile(id, data) {
        return prisma.user.update({
            where: { id },
            data,
            select: userPublicSelect,
        });
    },
    create(data) {
        return prisma.user.create({ data });
    },
    async primaryStoreIdForOwner(userId) {
        const s = await prisma.store.findFirst({
            where: { ownerUserId: userId, isActive: true },
            select: { id: true },
            orderBy: { createdAt: "asc" },
        });
        return s?.id ?? null;
    },
};
