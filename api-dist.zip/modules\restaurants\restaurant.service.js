import { prisma } from "../../lib/prisma.js";
import { HttpError } from "../../lib/http-error.js";
function toDto(r) {
    return {
        id: r.id,
        name: r.name,
        phone: r.phone,
        address: r.address,
        latitude: r.latitude,
        longitude: r.longitude,
        isActive: r.isActive,
        createdAt: r.createdAt.toISOString(),
        updatedAt: r.updatedAt.toISOString(),
    };
}
export async function createRestaurant(body) {
    const row = await prisma.restaurant.create({
        data: {
            name: body.name,
            phone: body.phone,
            address: body.address,
            latitude: body.latitude ?? null,
            longitude: body.longitude ?? null,
        },
    });
    return toDto(row);
}
export async function listRestaurants() {
    const rows = await prisma.restaurant.findMany({ orderBy: { createdAt: "desc" } });
    return rows.map(toDto);
}
export async function getRestaurant(id) {
    const row = await prisma.restaurant.findUnique({ where: { id } });
    if (!row)
        throw new HttpError(404, "Restaurant not found", "NOT_FOUND");
    return toDto(row);
}
export async function updateRestaurant(id, body) {
    try {
        const row = await prisma.restaurant.update({
            where: { id },
            data: {
                ...(body.name !== undefined ? { name: body.name } : {}),
                ...(body.phone !== undefined ? { phone: body.phone } : {}),
                ...(body.address !== undefined ? { address: body.address } : {}),
                ...(body.latitude !== undefined ? { latitude: body.latitude } : {}),
                ...(body.longitude !== undefined ? { longitude: body.longitude } : {}),
                ...(body.isActive !== undefined ? { isActive: body.isActive } : {}),
            },
        });
        return toDto(row);
    }
    catch {
        throw new HttpError(404, "Restaurant not found", "NOT_FOUND");
    }
}
