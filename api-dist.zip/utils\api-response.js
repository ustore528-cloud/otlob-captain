export function ok(data) {
    return { success: true, data };
}
export function fail(code, message, details) {
    return { success: false, error: { code, message, ...(details !== undefined ? { details } : {}) } };
}
