import { ZodError } from "zod";
import { HttpError } from "../lib/http-error.js";
export function errorHandler(err, _req, res, _next) {
    if (err instanceof HttpError) {
        return res.status(err.status).json({
            error: err.message,
            code: err.code,
            details: err.details,
        });
    }
    if (err instanceof ZodError) {
        return res.status(400).json({
            error: "Validation failed",
            code: "VALIDATION_ERROR",
            details: err.flatten(),
        });
    }
    console.error(err);
    return res.status(500).json({ error: "Internal server error", code: "INTERNAL" });
}
