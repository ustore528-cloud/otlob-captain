import { ok } from "../utils/api-response.js";
import { authService } from "../services/auth.service.js";
export const authController = {
    login: async (req, res) => {
        const body = req.body;
        const data = await authService.login(body);
        return res.json(ok(data));
    },
    refresh: async (req, res) => {
        const body = req.body;
        const data = await authService.refresh(body.refreshToken);
        return res.json(ok(data));
    },
    me: async (req, res) => {
        const data = await authService.me(req.user.id);
        return res.json(ok(data));
    },
    register: async (req, res) => {
        const data = await authService.register(req.body);
        return res.status(201).json(ok(data));
    },
};
