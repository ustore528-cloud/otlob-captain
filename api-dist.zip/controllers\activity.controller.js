import { ok } from "../utils/api-response.js";
import { activityReadService } from "../services/activity-read.service.js";
export const activityController = {
    list: async (req, res) => {
        const q = req.query;
        const data = await activityReadService.list({
            userId: q.userId,
            entityType: q.entityType,
            entityId: q.entityId,
            page: Number(q.page) || 1,
            pageSize: Number(q.pageSize) || 20,
        });
        return res.json(ok(data));
    },
};
