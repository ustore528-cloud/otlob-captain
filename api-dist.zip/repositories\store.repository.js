import { prisma } from "../lib/prisma.js";
export const storeRepository = {
    create(data) {
        return prisma.store.create({ data, include: { owner: { select: { id: true, fullName: true, phone: true } } } });
    },
    update(id, data) {
        return prisma.store.update({
            where: { id },
            data,
            include: { owner: { select: { id: true, fullName: true, phone: true } } },
        });
    },
    findById(id) {
        return prisma.store.findUnique({
            where: { id },
            include: { owner: { select: { id: true, fullName: true, phone: true, email: true } } },
        });
    },
    listByOwner(ownerUserId, params) {
        const where = { ownerUserId };
        return prisma.$transaction([
            prisma.store.count({ where }),
            prisma.store.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip: (params.page - 1) * params.pageSize,
                take: params.pageSize,
                include: { owner: { select: { id: true, fullName: true, phone: true } } },
            }),
        ]);
    },
    list(params) {
        const where = {};
        if (params.area)
            where.area = { contains: params.area, mode: "insensitive" };
        if (params.isActive !== undefined)
            where.isActive = params.isActive;
        return prisma.$transaction([
            prisma.store.count({ where }),
            prisma.store.findMany({
                where,
                orderBy: { createdAt: "desc" },
                skip: (params.page - 1) * params.pageSize,
                take: params.pageSize,
                include: { owner: { select: { id: true, fullName: true, phone: true } } },
            }),
        ]);
    },
};
