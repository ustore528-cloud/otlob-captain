export function generateOrderNumber() {
    const t = Date.now().toString(36).toUpperCase();
    const r = Math.random().toString(36).slice(2, 8).toUpperCase();
    return `ORD-${t}-${r}`;
}
