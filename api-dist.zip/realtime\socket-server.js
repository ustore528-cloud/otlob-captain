import { Server } from "socket.io";
import { resolveCorsOrigin } from "../config/cors-options.js";
import { verifyAccessToken } from "../lib/jwt.js";
import { setIo, rooms } from "./hub.js";
export function attachSocketIo(httpServer) {
    const io = new Server(httpServer, {
        cors: {
            origin: resolveCorsOrigin(),
            credentials: true,
        },
    });
    io.use((socket, next) => {
        try {
            const token = socket.handshake.auth?.token ??
                (typeof socket.handshake.query.token === "string" ? socket.handshake.query.token : undefined);
            if (!token)
                return next(new Error("Unauthorized"));
            const payload = verifyAccessToken(token);
            socket.data.userId = payload.sub;
            socket.data.role = payload.role;
            socket.data.storeId = payload.storeId;
            return next();
        }
        catch {
            return next(new Error("Unauthorized"));
        }
    });
    io.on("connection", (socket) => {
        const role = socket.data.role;
        const userId = socket.data.userId;
        const storeId = socket.data.storeId;
        if (role === "ADMIN" || role === "DISPATCHER") {
            void socket.join(rooms.dispatchers);
        }
        if (storeId && role === "STORE") {
            void socket.join(rooms.store(storeId));
        }
        if (role === "CAPTAIN") {
            void socket.join(rooms.captain(userId));
        }
    });
    setIo(io);
    return io;
}
