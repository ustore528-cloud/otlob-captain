export function pathParam(req, key) {
    const v = req.params[key];
    if (typeof v === "string")
        return v;
    if (Array.isArray(v))
        return v[0] ?? "";
    return "";
}
